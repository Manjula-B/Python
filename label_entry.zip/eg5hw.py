'''
from tkinter import *
from tkinter import messagebox

root = Tk()
firstnamevar = StringVar()
lastnamevar = StringVar()
emailvar = StringVar()
passwordvar = StringVar()
cfpassword = StringVar()

def sayme():
    messagebox.showinfo("My program","just checked !!!!")
    firstnameData = firstnamevar.get()
    lastnameData = lastnamevar.get()
    emailData = emailvar.get()
    print("First Name = ",firstnameData,"Last Name = ",lastnameData, " Email data = ",emailData)
    passwordData = passwordvar.get()
    print("Password Data = ",passwordData)
    cfpasswordData = cfpasswordvar.get()
    print("CFPassword Data = ",cfpasswordData)


root.geometry("300x350")
firstname = Label(root,text="FIRSTNAME").place(x=30,y=50)
e1 = Entry(root,textvariable = firstnamevar).place(x=160,y=50)

lastname = Label(root,text="LASTNAME").place(x=30,y=100)
e2 = Entry(root,textvariable = lastnamevar).place(x=160,y=100)

email = Label(root,text="EMAIL").place(x=30,y=150)
e3 = Entry(root,textvariable = emailvar).place(x=160,y=150)

password = Label(root,text="PASSWORD").place(x=30,y=200)
e4 = Entry(root,textvariable = passwordvar).place(x=160,y=200)

cfpassword = Label(root,text="CONFIRM PASSWORD").place(x=30,y=250)
e5= Entry(root,textvariable=cfpasswordvar).place(x=160,y=250)

btn = Button(root,text="SUBMIT",bg="black",fg="white",command=sayme).place(x=30,y=300)
root.mainloop()
'''






from tkinter import *
from tkinter import messagebox

root= Tk()
root.configure(bg='#eeffff')
root.title('Form')
firstnamevar = StringVar()
lastnamevar =StringVar()
emailvar= StringVar()
pwvar=StringVar()
confpwvar=StringVar()
root.resizable(False,False)


def notify():

    messagebox.showinfo("My form","confirm submission !!!!")
    firstnameData = firstnamevar.get()
    lastnameData = lastnamevar.get()
    emailData = emailvar.get()
    pwData=pwvar.get()
    confpwData=confpwvar.get()
    print("First Name = ",firstnameData,"Last Name = ",lastnameData ," EMAIL = ",emailData,"PASSWORD = ",pwData,"CONFIRM PASSWORD = ",confpwData)
    pw = pwvar.get()
    confpw = confpwvar.get()
    if pw ==  confpw:
        messagebox.showinfo("My form","password confirmed")

    else:
        messagebox.showinfo("My from","invalid try again")



root.geometry("500x350")

firstname = Label(root,text="FIRST NAME").place(x=30,y=50)
e1 = Entry(root,textvariable = firstnamevar).place(x=160,y=50)

lastname = Label(root,text="LAST NAME").place(x=30,y=100)
e2 = Entry(root,textvariable = lastnamevar).place(x=160,y=100)

email = Label(root,text="EMAIL").place(x=30,y=150)
e3 = Entry(root,textvariable=emailvar).place(x=160,y=150)

pw = Label(root,text="PASSWORD").place(x=30,y=200)
e4 = Entry(root,textvariable=pwvar,show="*").place(x=160,y=200)

confpw = Label(root,text="CONFIRM PASSWORD").place(x=30,y=250)
e5= Entry(root,textvariable=confpwvar,show="*").place(x=160,y=250)


btn = Button(root,text="SUBMIT",bg="blue",fg="black",command=notify).place(x=30,y=300)

root.mainloop()



