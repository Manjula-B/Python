from tkinter import *
root = Tk()
root.iconbitmap(r.ico')
root.mainloop()
