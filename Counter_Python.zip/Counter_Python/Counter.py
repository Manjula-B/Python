from tkinter import*

root=Tk()
root.geometry("400x250")
root.title("COUNTER")
root.iconbitmap(r'countdown.ico')
root.configure(bg="#ffe6e6")
root.resizable(width=False,height=False)
counter = 0
counting = False

def counter_label(label):
    def count():
        if counting:
            global counter
            if counter==0:
                display="Start counting..."
            else:
                display=str(counter)
            label["text"]=display
            label.after(1000, count)
            counter += 1
    count()

def Start(label):
    global counting
    counting=True
    counter_label(label)
    start["state"]="disabled"
    pause["state"]="normal"
    stop["state"]="normal"
    exit["state"]="normal"
    reset["state"]="normal"
    display["state"]="disabled"

def Pause():
    global counting
    start["state"]="normal"
    pause["state"]="disabled"
    reset["state"]="normal"
    exit["state"]="normal"
    stop["state"]="normal"
    counting = False

def Reset(label):
    global counter
    global counting
    start["state"]="normal"
    stop["state"]="disabled"
    display["state"]="disabled"
    pause["state"]="disabled"

    counter =0
    counting = False

    if counting==False:
        reset["state"]="disabled"
        label["text"]="COUNTER"
        counter=0
    else:
        label["text"]="start counting..."

def Stop():
    global counting
    counting = False
    display["state"]="normal"

def Display():
    global counting
    counting= False
    label["text"]="counter value = ",counter-1

def Exit():
    root.destroy()
state = False

label = Label(root,text="COUNTER",fg="black",bg="#ffe6e6",font=("Helvetica",20,"bold"))
label.pack()

start =Button(root, text="START",width=15, command=lambda:Start(label),fg="#006600",bg="white",font=("Georgia",10,"bold"),relief=RAISED)
pause = Button(root, text="PAUSE",width=15, state="disabled", command=Pause,fg="#1a53ff",bg="white",font=("Georgia",10,"bold"),relief=RAISED)
reset = Button(root, text="RESET",width=15, state="disabled", command=lambda:Reset(label),fg="#4d0066",bg="white",font=("Georgia",10,"bold"),relief=RAISED)
stop= Button(root, text="STOP",width=15, state="disabled", command=Stop,fg="#ff0000",bg="white",font=("Georgia",10,"bold"),relief=RAISED)
display= Button(root, text="DISPLAY",width=15, state="disabled", command=Display,fg="#000066",bg="white",font=("Georgia",10,"bold"),relief=RAISED)
exit= Button(root, text="EXIT",width=15, state="disabled", command=Exit,fg="#b30000",bg="white",font=("Georgia",10,"bold"),relief=RAISED)

start.pack()
pause.pack()
reset.pack()
stop.pack()
display.pack()
exit.pack()
root.mainloop()
